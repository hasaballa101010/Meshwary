package com.meshwary.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF123B32)
private val Lime = Color(0xFFD9F99D)
private val Pale = Color(0xFFF4F7F6)

data class Trip(
    val id: Long, val type: String, val start: String, val end: String,
    val fare: Double, val expense: Double, val distance: Double, val timestamp: Long
) {
    val net: Double get() = fare - expense
    fun toJson() = JSONObject().apply {
        put("id", id); put("type", type); put("start", start); put("end", end)
        put("fare", fare); put("expense", expense); put("distance", distance); put("timestamp", timestamp)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeshwaryApp(this) }
    }
}

private fun money(n: Double) = String.format(Locale("en", "US"), "%,.2f", n)
private fun dayKey(t: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))
private fun monthKey(t: Long) = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(t))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeshwaryApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("meshwary_data", Context.MODE_PRIVATE) }
    var trips by remember {
        mutableStateOf(run {
            val arr = runCatching { JSONArray(prefs.getString("trips", "[]")) }.getOrDefault(JSONArray())
            (0 until arr.length()).mapNotNull { i ->
                runCatching {
                    val o = arr.getJSONObject(i)
                    Trip(o.getLong("id"), o.getString("type"), o.optString("start"), o.optString("end"),
                        o.getDouble("fare"), o.getDouble("expense"), o.getDouble("distance"), o.getLong("timestamp"))
                }.getOrNull()
            }.sortedByDescending { it.timestamp }
        })
    }
    var fuel by remember { mutableStateOf(prefs.getString("fuel", "0") ?: "0") }
    var other by remember { mutableStateOf(prefs.getString("other", "0") ?: "0") }
    var goal by remember { mutableStateOf(prefs.getString("goal", "1000") ?: "1000") }
    var tab by remember { mutableStateOf("الرئيسية") }
    var showAdd by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    fun persistTrips(list: List<Trip>) {
        trips = list
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        prefs.edit().putString("trips", a.toString()).apply()
    }
    val todayTrips = trips.filter { dayKey(it.timestamp) == dayKey(System.currentTimeMillis()) }
    val monthTrips = trips.filter { monthKey(it.timestamp) == monthKey(System.currentTimeMillis()) }
    val todayRevenue = todayTrips.sumOf { it.fare }
    val todayNet = todayTrips.sumOf { it.net } - (fuel.toDoubleOrNull() ?: 0.0) - (other.toDoubleOrNull() ?: 0.0)
    val monthRevenue = monthTrips.sumOf { it.fare }
    val monthNet = monthTrips.sumOf { it.net } - (fuel.toDoubleOrNull() ?: 0.0) - (other.toDoubleOrNull() ?: 0.0)

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Lime, background = Pale)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("مشواري 🚗", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text("رفيقك في كل مشوار", color = Color(0xFFC8E5D9), fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Green)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("الرئيسية", "المشاوير", "المصاريف", "التقارير").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item; showAdd = false },
                            icon = { Text(when(item) { "الرئيسية" -> "⌂"; "المشاوير" -> "🚘"; "المصاريف" -> "ج.م"; else -> "▥" }) },
                            label = { Text(item, fontSize = 11.sp) }
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (notice.isNotBlank()) {
                    Text(notice, Modifier.fillMaxWidth().background(Color(0xFFE2F3E8)).padding(10.dp), color = Green)
                }
                when (tab) {
                    "الرئيسية" -> {
                        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            item {
                                Column(Modifier.fillMaxWidth().background(Green, RoundedCornerShape(22.dp)).padding(18.dp)) {
                                    Text("أهلاً يا كابتن 👋", color = Color(0xFFC8E5D9))
                                    Spacer(Modifier.height(8.dp))
                                    Text("ملخص النهارده", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(14.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        MetricCard("إيرادات اليوم", "${money(todayRevenue)} ج.م", Modifier.weight(1f))
                                        MetricCard("صافي اليوم*", "${money(todayNet)} ج.م", Modifier.weight(1f), light = true)
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("* بعد خصم المصاريف المسجلة", color = Color(0xFFC8E5D9), fontSize = 11.sp)
                                }
                            }
                            item {
                                Button(onClick = { tab = "المشاوير"; showAdd = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                                    Text("+ تسجيل مشوار جديد")
                                }
                            }
                            item { Text("آخر المشاوير", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Green) }
                            if (trips.isEmpty()) item { Text("لسه مفيش مشاوير. سجّل أول مشوار ليك.", color = Color.Gray) }
                            items(trips.take(5), key = { it.id }) { trip ->
                                TripCard(trip, onDelete = { persistTrips(trips.filterNot { it.id == trip.id }); notice = "تم حذف المشوار." })
                            }
                        }
                    }
                    "المشاوير" -> {
                        Column(Modifier.fillMaxSize().padding(16.dp)) {
                            Button(onClick = { showAdd = !showAdd }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                                Text(if (showAdd) "إغلاق النموذج" else "+ إضافة مشوار")
                            }
                            if (showAdd) {
                                Spacer(Modifier.height(10.dp))
                                AddTripForm(onSave = { type, start, end, fare, expense, distance ->
                                    val trip = Trip(System.currentTimeMillis(), type, start, end, fare, expense, distance, System.currentTimeMillis())
                                    persistTrips((listOf(trip) + trips).sortedByDescending { it.timestamp })
                                    showAdd = false
                                    notice = "تم حفظ المشوار على الجهاز."
                                })
                            }
                            Spacer(Modifier.height(10.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(trips, key = { it.id }) { trip ->
                                    TripCard(trip, onDelete = { persistTrips(trips.filterNot { it.id == trip.id }); notice = "تم حذف المشوار." })
                                }
                            }
                        }
                    }
                    "المصاريف" -> {
                        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("مصاريف العربية", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
                            Text("تُخصم هذه المصاريف من ملخص اليوم والشهر.")
                            MoneyField("البنزين اليومي (ج.م)", fuel) { fuel = it; prefs.edit().putString("fuel", it).apply() }
                            MoneyField("صيانة ومصاريف أخرى (ج.م)", other) { other = it; prefs.edit().putString("other", it).apply() }
                            MoneyField("هدف الربح اليومي (ج.م)", goal) { goal = it; prefs.edit().putString("goal", it).apply() }
                            val target = goal.toDoubleOrNull() ?: 0.0
                            Text(if (target > 0) "تقدمك نحو الهدف: ${((todayNet / target) * 100).toInt().coerceAtLeast(0)}%" else "اكتب هدفًا أكبر من صفر")
                            LinearProgressIndicator(progress = { if (target > 0) (todayNet / target).coerceIn(0.0, 1.0).toFloat() else 0f }, modifier = Modifier.fillMaxWidth())
                            Text("ملاحظة: مصروفات البنزين والمصاريف الأخرى تُحسب على اليوم الحالي فقط في التقارير.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                    else -> {
                        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            item { Text("تقارير الأرباح", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Green) }
                            item { ReportCard("اليوم", todayTrips.size, todayRevenue, todayTrips.sumOf { it.expense }, todayNet) }
                            item { ReportCard("الشهر الحالي", monthTrips.size, monthRevenue, monthTrips.sumOf { it.expense }, monthNet) }
                            item { Text("المسافة المسجلة هذا الشهر: ${money(monthTrips.sumOf { it.distance })} كم", color = Green) }
                            item {
                                OutlinedButton(onClick = {
                                    val report = buildString {
                                        append("تقرير مشواري\n")
                                        append("عدد مشاوير اليوم: ${todayTrips.size}\n")
                                        append("إيرادات اليوم: ${money(todayRevenue)} ج.م\n")
                                        append("صافي اليوم: ${money(todayNet)} ج.م\n")
                                        append("عدد مشاوير الشهر: ${monthTrips.size}\n")
                                        append("إيرادات الشهر: ${money(monthRevenue)} ج.م\n")
                                        append("صافي الشهر: ${money(monthNet)} ج.م")
                                    }
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("تقرير مشواري", report))
                                    notice = "تم نسخ التقرير. تقدر تلصقه في أي رسالة."
                                }, modifier = Modifier.fillMaxWidth()) { Text("نسخ التقرير") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier, light: Boolean = false) {
    Column(modifier.background(if (light) Lime else Color(0xFF245348), RoundedCornerShape(15.dp)).padding(12.dp)) {
        Text(label, color = if (light) Green else Color(0xFFC8E5D9), fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))
        Text(value, color = if (light) Green else Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
private fun TripCard(trip: Trip, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(trip.type, color = Green, fontWeight = FontWeight.Bold)
                Text("${money(trip.fare)} ج.م", color = Green, fontWeight = FontWeight.Bold)
            }
            if (trip.start.isNotBlank() || trip.end.isNotBlank()) {
                Text("${trip.start.ifBlank { "نقطة البداية غير محددة" }}  ←  ${trip.end.ifBlank { "نقطة النهاية غير محددة" }}", color = Color.DarkGray, fontSize = 12.sp)
            }
            Text("${money(trip.distance)} كم · مصروفات ${money(trip.expense)} ج.م · الصافي ${money(trip.net)} ج.م", color = Color.Gray, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDelete) { Text("حذف", color = Color(0xFF9B4444)) }
            }
        }
    }
}

@Composable
private fun MoneyField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { s -> if (s.isEmpty() || s.matches(Regex("^\\\\d*(\\\\.\\\\d{0,2})?$"))) onChange(s) },
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
private fun AddTripForm(onSave: (String, String, String, Double, Double, Double) -> Unit) {
    var type by remember { mutableStateOf("مشوار خاص") }
    var start by remember { mutableStateOf("") }
    var end by remember { mutableStateOf("") }
    var fare by remember { mutableStateOf("") }
    var expense by remember { mutableStateOf("0") }
    var distance by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf("") }

    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("بيانات المشوار", fontWeight = FontWeight.Bold, color = Green, fontSize = 18.sp)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(value = type, onValueChange = {}, readOnly = true, label = { Text("نوع المشوار") },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    listOf("مشوار خاص", "توصيل طلبات", "مشوار تطبيق").forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = { type = option; expanded = false })
                    }
                }
            }
            OutlinedTextField(start, { start = it }, label = { Text("نقطة البداية (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(end, { end = it }, label = { Text("نقطة النهاية (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            MoneyField("أجرة المشوار (ج.م)", fare) { fare = it }
            MoneyField("مصروف المشوار (ج.م)", expense) { expense = it }
            MoneyField("المسافة (كم)", distance) { distance = it }
            if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp)
            Button(onClick = {
                val f = fare.toDoubleOrNull()
                val e = expense.toDoubleOrNull()
                val d = distance.toDoubleOrNull()
                if (f == null || f <= 0 || e == null || e < 0 || d == null || d < 0) {
                    error = "أدخل أجرة أكبر من صفر، ومصاريف ومسافة صحيحتين."
                } else onSave(type, start.trim(), end.trim(), f, e, d)
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text("حفظ المشوار")
            }
        }
    }
}

@Composable
private fun ReportCard(title: String, count: Int, revenue: Double, tripExpenses: Double, net: Double) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("عدد المشاوير: $count")
            Text("الإيرادات: ${money(revenue)} ج.م")
            Text("مصروفات المشاوير: ${money(tripExpenses)} ج.م")
            HorizontalDivider()
            Text("صافي الربح بعد المصاريف المسجلة: ${money(net)} ج.م", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}
